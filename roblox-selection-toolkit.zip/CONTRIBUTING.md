# Contributing

Thank you for considering a contribution!

1. Open an issue describing the bug or suggested improvement.
2. Fork the repository and create a branch for your change.
3. Keep the plugin self-contained and avoid unnecessary dependencies.
4. Test your change in Roblox Studio using a local plugin.
5. Open a pull request summarizing the change and your test results.

Please be respectful and do not submit code that collects user data without clear disclosure and consent.
