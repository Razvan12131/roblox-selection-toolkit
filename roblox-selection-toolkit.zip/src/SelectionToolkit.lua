--!strict
-- Roblox Selection Toolkit
-- Install this Script as a LOCAL PLUGIN in Roblox Studio.
-- The global `plugin` is available only when run as a Studio plugin.

local Selection = game:GetService("Selection")
local ChangeHistoryService = game:GetService("ChangeHistoryService")

local toolbar = plugin:CreateToolbar("Selection Toolkit")

local function createButton(id: string, tooltip: string)
    local button = toolbar:CreateButton(id, tooltip, "")
    button.ClickableWhenViewportHidden = true
    return button
end

local anchorButton = createButton("Anchor", "Anchor selected parts and parts inside selected models")
local unanchorButton = createButton("Unanchor", "Unanchor selected parts and parts inside selected models")
local collisionOnButton = createButton("Collide ON", "Enable CanCollide on the selected parts")
local collisionOffButton = createButton("Collide OFF", "Disable CanCollide on the selected parts")

-- Include BaseParts inside selected Models/Folders, without double-processing.
local function collectParts(): {BasePart}
    local found: {[BasePart]: boolean} = {}
    local parts: {BasePart} = {}

    local function addPart(instance: Instance)
        if instance:IsA("BasePart") and not found[instance] then
            found[instance] = true
            table.insert(parts, instance)
        end
    end

    for _, selected in Selection:Get() do
        addPart(selected)
        for _, descendant in selected:GetDescendants() do
            addPart(descendant)
        end
    end

    return parts
end

local function updateParts(propertyName: "Anchored" | "CanCollide", value: boolean, label: string)
    local changes: {BasePart} = {}

    for _, part in collectParts() do
        local current = if propertyName == "Anchored" then part.Anchored else part.CanCollide
        if current ~= value then
            table.insert(changes, part)
        end
    end

    if #changes == 0 then
        print("[Selection Toolkit] No changes needed for " .. label .. ".")
        return
    end

    -- One undo/redo entry for the entire bulk edit.
    local recording = ChangeHistoryService:TryBeginRecording(label, label)
    if not recording then
        warn("[Selection Toolkit] Can't start an undo recording. Try again outside Play mode.")
        return
    end

    local success, err = pcall(function()
        for _, part in changes do
            if propertyName == "Anchored" then
                part.Anchored = value
            else
                part.CanCollide = value
            end
        end
    end)

    if success then
        ChangeHistoryService:FinishRecording(recording, Enum.FinishRecordingOperation.Commit)
        print(string.format("[Selection Toolkit] %s: %d part(s) updated.", label, #changes))
    else
        ChangeHistoryService:FinishRecording(recording, Enum.FinishRecordingOperation.Cancel)
        warn("[Selection Toolkit] Operation canceled: " .. tostring(err))
    end
end

anchorButton.Click:Connect(function()
    updateParts("Anchored", true, "Anchor selected parts")
end)

unanchorButton.Click:Connect(function()
    updateParts("Anchored", false, "Unanchor selected parts")
end)

collisionOnButton.Click:Connect(function()
    updateParts("CanCollide", true, "Enable collisions")
end)

collisionOffButton.Click:Connect(function()
    updateParts("CanCollide", false, "Disable collisions")
end)
