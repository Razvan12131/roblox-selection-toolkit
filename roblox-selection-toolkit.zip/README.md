# Roblox Selection Toolkit

A small, free, open-source **Roblox Studio plugin** for editing lots of parts at once.

> **Status:** Source code is ready to try in Roblox Studio. It has not yet been tested in a live Studio installation; bug reports are welcome.

## Features

- **Anchor** selected parts, including parts inside selected Models and Folders.
- **Unanchor** selected parts.
- **Collide ON** sets `CanCollide = true`.
- **Collide OFF** sets `CanCollide = false`.
- **Undo / redo support:** Each click is recorded as one Studio undo step.
- **No data collection, network calls, or external dependencies.**

## Install as a local Studio plugin

1. Download this repository (green **Code** button → **Download ZIP**) and extract it.
2. Open **Roblox Studio** and a place you can edit.
3. In **Explorer**, insert a temporary **Script**, for example under `ServerScriptService`.
4. Open [`src/SelectionToolkit.lua`](src/SelectionToolkit.lua) in a text editor, copy **all** the code, and replace the Script's content with it.
5. Right-click that Script in Explorer and choose **Save as Local Plugin**. Give it the name **Selection Toolkit**.
6. Remove the temporary Script from your game after installing the plugin. The plugin should now appear in Studio's **Plugins** tab.

If the buttons don't appear immediately, restart Studio or reload the plugin. You can also inspect the **Output** window for errors.

## Use

1. Select one or several Parts, Models, or Folders in Explorer (or parts in the viewport).
2. On the **Plugins** tab, find **Selection Toolkit**.
3. Click **Anchor**, **Unanchor**, **Collide ON**, or **Collide OFF**.
4. Press `Ctrl+Z` (Windows) to undo the change.

The plugin updates only `BasePart` objects. It does **not** edit scripts, save files, or send information anywhere.

## Example

Select a model containing 150 parts, then click **Anchor** to anchor all of its parts at once.

## Contributing

Issues and pull requests are welcome. Please describe the bug or improvement, include reproduction steps if relevant, and test changes in Roblox Studio before submitting.

## License

MIT — see [LICENSE](LICENSE).

## Roblox API references

- [Creating Studio plugins](https://create.roblox.com/docs/studio/plugins)
- [ChangeHistoryService (undo/redo)](https://create.roblox.com/docs/reference/engine/classes/ChangeHistoryService)

This is an independent community tool, not an official Roblox product.
